# EXISTING COVERAGE BRIEF — what the estate ALREADY has

## A · The trap register (fleet-manager docs/traps.md) — 7 traps
## TRAP-001 · A dated document read as current state
- **TRIGGER** — you are about to state what is *true now* — a service exists, a
## TRAP-002 · An exit code read after a pipe
- **TRIGGER** — a shell command containing a pipe, whose result you then read
## TRAP-003 · Absence of evidence recorded as evidence of absence
- **TRIGGER** — you are about to write that something is **not** there — not
## TRAP-004 · A claim wider than the sample that produced it
- **TRIGGER** — you are about to write a fraction, a total, or a universal
## TRAP-005 · The owner corrected from memory and was right
- **TRIGGER** — the owner states something about this estate that contradicts
## TRAP-006 · A session card flipped to `complete` before the branch is pushed
- **TRIGGER** — you are about to `git push` a branch whose in-diff
## TRAP-007 · A card flipped to `complete` while a requested review is unanswered

## B · doc-routes.json — the 71 delivery routes (id · trigger)
- recording-a-wall | ['·\\s*wall\\s*·', '\\b(is|are|was|were)\\s+not\\s+(available|supported|reachable|possible|enabled)', '\\bunavailable\\b', '\\bcannot be (used|called|
- discovery-probe | ['\\$discovery', 'discovery\\.googleapis\\.com', '\\$rest\\b', '\\?fields=.*methods', 'openapi\\.json', '/\\$metadata']
- adversarial-review | ['adversarial[- ]review', 'provenance-review', 'provenance-mechanism', 'owner stand-in', 'ownerreview', 'what made you draw', 'review mandate']
- gemini | [':generateContent', 'GEMINI_API_KEY', 'GEMINI_API_KEY_PAID', 'GEMINI_VERTEX_SA', 'aiplatform\\.googleapis\\.com', 'deep[-_ ]?research', 'gemini-[0-9]
- github-api | ['api\\.github\\.com', '\\bgh\\s+api\\b', 'GITHUB_PAT', 'uploads\\.github\\.com']
- railway | ['backboard\\.railway\\.com', 'RAILWAY_API_KEY', '\\brailway\\s+(variables|run|up|link|logs)\\b']
- provisioned-secrets | ['DISCORD_TOKEN', 'discord\\.com/api', 'printenv\\s*\\|\\s*grep', '\\bBOT_TOKEN\\b']
- video-audio | ['\\bffmpeg\\b', '\\bffprobe\\b', '\\.(mp4|webm|mov|mkv|mp3|wav|m4a|ogg)\\b']
- youtube | ['youtube_transcript_api', 'youtube\\.com/watch', 'youtu\\.be/', '\\byt-dlp\\b']
- shared-ai-chat | ['chatgpt\\.com/share', 'claude\\.ai/share', 'g\\.co/gemini/share', 'gemini\\.google\\.com/share', 'read_shared_chat']
- openai | ['api\\.openai\\.com', 'OPENAI_API_KEY', '\\bcodex\\b']
- anthropic | ['api\\.anthropic\\.com', 'ANTHROPIC_API_KEY', 'platform\\.claude\\.com']
- deepseek | ['api\\.deepseek\\.com', 'DEEPSEEK_API_KEY', 'deepseek-(chat|reasoner|v[0-9])']
- grok | ['api\\.x\\.ai', 'XAI_API_KEY', '\\bgrok-[0-9]']
- mistral | ['api\\.mistral\\.ai', 'MISTRAL_API_KEY', 'mistral-(large|small|medium)']
- cohere | ['api\\.cohere', 'COHERE_API_KEY', 'command-a']
- copilot | ['\\bcopilot\\b', 'githubcopilot\\.com']
- llama | ['ai\\.meta\\.com', '\\bllama-?[34]\\b', 'llama\\.cpp']
- owner-drive | ['drive\\.google\\.com', 'drive\\.usercontent\\.google\\.com', 'GOOGLE_DRIVE']
- outbox | ['\\boutbox\\b']
- empty-repo-first-commit | ['git push.*--set-upstream.*\\bmain\\b.*\\bempty\\b', 'create_or_update_file']
- repo-spider-swing | ['\\bspider[- ]swing\\b', "\\bslingy[- ]spider\\b(?!['’]s[- ]community[- ]bot|[- ](?:(?:discord[- ])?server|(?:community[- ])?bot))", 'menno420/spider
- repo-spider-swing-prompt | ['\\bspider[- ]swing\\b', "\\bslingy[- ]spider\\b(?!['’]s[- ]community[- ]bot|[- ](?:(?:discord[- ])?server|(?:community[- ])?bot))", 'menno420/spider
- repo-spider-bot | ['\\bspider[- ]bot\\b', '\\b(?:the[- ])?community[- ]bot(?:[- ](?:in|of|for)[- ](?:the[- ])?slingy[- ]spider(?:[- ](?:discord[- ])?server)?)?\\b', '\\
- repo-spider-bot-prompt | ['\\bspider[- ]bot\\b', '\\b(?:the[- ])?community[- ]bot(?:[- ](?:in|of|for)[- ](?:the[- ])?slingy[- ]spider(?:[- ](?:discord[- ])?server)?)?\\b', '\\
- repo-couch-legend | ['\\bcouch[- ]legend\\b', '\\bidle[- ]stoner\\b', '\\blucid[- ]chronicle\\b', 'menno420/couch-legend']
- repo-couch-legend-prompt | ['\\bcouch[- ]legend\\b', '\\bidle[- ]stoner\\b', '\\blucid[- ]chronicle\\b', 'menno420/couch-legend']
- error-review | ['caus[a-z]*\\s+(all\\s+)?these\\s+mistakes', "mistakes\\s+don'?t\\s+happen", 'follow the rules and guides', "why the rules don'?t bind"]
- repo-websites | ['menno420/websites', '\\bwebsites repo\\b', '\\bcontrol[- ]plane\\b', '\\bbotsite\\b', '\\breview[- ]site\\b']
- repo-websites-prompt | ['menno420/websites', '\\bwebsites repo\\b', '\\bcontrol[- ]plane\\b', '\\bbotsite\\b', '\\breview[- ]site\\b', '\\b(the|my) websites\\b']
- repo-superbot | ['menno420/superbot(?![\\w-])', '\\bsuperbot repo\\b', '\\bworker service\\b', '\\bsuperbot\\b(?![\\w-])(?! ?(next|idle|games|mineverse|world|plugin|2
- repo-superbot-prompt | ['menno420/superbot(?![\\w-])', '\\bsuperbot repo\\b', '\\bworker service\\b', '\\bsuperbot\\b(?![\\w-])(?! ?(next|idle|games|mineverse|world|plugin|2
- repo-estate-backups | ['menno420/estate-backups', '\\bestate[- ]backups\\b']
- repo-estate-backups-prompt | ['menno420/estate-backups', '\\bestate[- ]backups\\b']
- repo-product-forge | ['\\bproduct[- ]forge\\b', '\\bphone[- ]controller\\b', '\\bcontroller app\\b', 'menno420/product-forge']
- repo-product-forge-prompt | ['\\bproduct[- ]forge\\b', '\\bphone[- ]controller\\b', '\\bcontroller app\\b', 'menno420/product-forge']
- repo-superbot-next | ['\\bsuperbot[- ]next\\b', '\\bsuperbot 2\\.0\\b', 'menno420/superbot-next']
- repo-superbot-next-prompt | ['\\bsuperbot[- ]next\\b', '\\bsuperbot 2\\.0\\b', '\\bthe rebuild\\b', '\\bthe old rebuild\\b', 'menno420/superbot-next']
- repo-substrate-kit | ['\\bsubstrate[- ]kit\\b(?![- ](?:app|dashboard))', '\\bthe[- ]kit\\b(?![- ]dashboard)', 'menno420/substrate-kit(?![\\w-])']
- repo-substrate-kit-prompt | ['\\bsubstrate[- ]kit\\b(?![- ](?:app|dashboard))', '\\bthe[- ]kit\\b(?![- ]dashboard)', '\\bkit release\\b', 'menno420/substrate-kit(?![\\w-])']
- repo-venture-lab | ['\\bventure[- ]lab\\b', '\\bstripe webhook test kit\\b', '\\bnight kiln\\b', '\\blull/dreamline\\b', '\\bdreamline\\b', '\\bultramarine\\b', 'menno42
- repo-venture-lab-prompt | ['\\bventure[- ]lab\\b', '\\bstripe webhook test kit\\b', '\\bnight kiln\\b', '\\blull/dreamline\\b', '\\bdreamline\\b', '\\bultramarine\\b', 'menno42
- estate-superbot-world | ['\\bsuperbot[- ](games|idle|mineverse)\\b', '\\bmineverse\\b', '\\bsuperbot[- ]world\\b', '\\bsuperbot[- ]plugin[- ]hello\\b', '\\bplugin[- ]hello\\b
- estate-superbot-world-prompt | ['\\bsuperbot[- ](games|idle|mineverse)\\b', '\\bmineverse\\b', '\\bsuperbot[- ]world\\b', '\\bsuperbot[- ]plugin[- ]hello\\b', '\\bplugin[- ]hello\\b
- estate-codetools | ['\\bcodetool[- ]labs?\\b', '\\bcodetool-lab-(?:opus4\\.8|fable5|sonnet5)\\b', '\\bmdverify\\b', '\\benvdrift\\b(?!\\.py)', '\\bcfgdiff\\b']
- estate-codetools-prompt | ['\\bcodetool[- ]labs?\\b', '\\bcodetool-lab-(?:opus4\\.8|fable5|sonnet5)\\b', '\\bmdverify\\b', '\\benvdrift\\b(?!\\.py)', '\\bcfgdiff\\b']
- estate-shiftlife | ['\\bshiftlife\\b', 'menno420/shiftlife']
- estate-shiftlife-prompt | ['\\bshiftlife\\b', '\\bshift calendar\\b', 'menno420/shiftlife']
- estate-gba-pokemon | ['\\bgba[- ]homebrew\\b', '\\bpokemon[- ]mod[- ]lab\\b', '\\blumen[- ]drift\\b', '\\bwickroad\\b', '\\bbrineward\\b', '\\bunderroot\\b']
- estate-gba-pokemon-prompt | ['\\bgba[- ]homebrew\\b', '\\bpokemon[- ]mod[- ]lab\\b', '\\bgba (project|game|games|rom|roms)\\b', '\\bpokemon (mod|hack)\\b', '\\blumen[- ]drift\\b'
- estate-research | ['\\bidea[- ]engine\\b', '\\bsim[- ]lab\\b', '\\btrading[- ]strategy\\b', '\\btrading[- ]lab\\b', '\\bcurious[- ]research\\b']
- estate-research-prompt | ['\\bidea[- ]engine\\b', '\\bsim[- ]lab\\b', '\\btrading[- ]strategy\\b', '\\btrading[- ]lab\\b', '\\bcurious[- ]research\\b', '\\bideas lab\\b']
- estate-kit-app | ['\\bsubstrate[- ]kit[- ](?:app|dashboard)\\b', '\\bkit dashboard\\b']
- estate-kit-app-prompt | ['\\bsubstrate[- ]kit[- ](?:app|dashboard)\\b', '\\bkit dashboard\\b']
- estate-proxybench | ['\\bproxybench\\b']
- estate-proxybench-prompt | ['\\bproxybench\\b']
- repo-disposition-2026-08-22 | ['\\barchiv(e|ed|ing)\\b', '\\bdispositions?\\b', '\\bstart(ing)? fresh\\b', '\\brework(ed|ing)?\\b', '\\bwhich repos to keep\\b', '\\bkeep[- ]?vs[- ]
- exit-code-after-a-pipe | ['\\|[\\s\\S]{0,400}\\$\\?']
- stamping-a-measured-claim | ['`?MEASURED`?\\b', '\\bmeasured\\s+(live|2026-)', '\\bverified live\\b']
- absence-claim | ['\\bno (hits|results|matches|consumers|references|dependents)\\b', '\\bnothing (in|else|found)\\b', '\\bzero hits\\b', '\\bnot (indexed|referenced|pr
- claim-beyond-the-sample | ['\\bonly \\d+ of \\d+\\b', '\\b\\d+ of (the )?\\d+ (repos|repositories|files|entries|cards|commits|sessions|PRs|pull requests|notifications|findings|
- card-flip-before-push | ['(?:^|[;&|]|\\Bcd\\s)\\s*git\\b(?:\\s+(?:-[cC]\\s*\\S+|-[pP]\\b|--\\S+))*\\s+push\\b']
- card-flip-to-complete | ['Status:\\**\\s*`?complete`?']
- card-status-write | ['\\.sessions/.*\\.md']
- codex-verdict-poll | ['pulls/(?:\\d+|\\{n\\}|\\$\\{?\\w+\\}?)/reviews', 'issues/(?:\\d+|\\{n\\}|\\$\\{?\\w+\\}?)/comments', 'pulls/(?:\\d+|\\{n\\}|\\$\\{?\\w+\\}?)/comment
- gemini-notebook | ['\\bnotebooklm\\b', '\\bgemini[- ]notebook', '\\bnotebook (bundle|corpus|sources)\\b', 'build_notebook_bundle', 'OQ-GEMINI-NOTEBOOKS']
- gemini-notebook-prompt | ['\\bnotebooklm\\b', '\\bgemini[- ]notebook', '\\bnotebook (bundle|corpus|sources)\\b', 'OQ-GEMINI-NOTEBOOKS']
- session-card-venue | ['📊\\s*Model:', '\\.sessions/\\d{4}-\\d{2}-\\d{2}-']
- cross-session-visibility | ['\\blocal session', '\\bcross[- ]session', '\\bwhat (have|has|did) (the |my |his )?(other |local |cloud )?(sessions?|ai|ais)\\b', '\\bwhile I was awa
- shallow-clone-commit-counts | ['git\\s+(log|rev-list|shortlog)\\b', 'git\\s+log[^|]*\\|\\s*wc\\b']
- execution-packets-prompt | ['\\bPKT-[A-D]\\d', '\\b(execution|work) packets?\\b', '\\bpacket plan\\b']

## C · substrate-kit at main — checkers, skills, hooks (live tree)

### checkers / check scripts
- scripts/check_bench_integrity.py
- scripts/check_changelog_structure.py
- scripts/check_idea_index.py
- scripts/check_program_law.py
- scripts/check_retro_index.py
- scripts/check_taxonomy_sync.py
- src/engine/checks/__init__.py
- src/engine/checks/allowlist.py
- src/engine/checks/check_adopters_current.py
- src/engine/checks/check_archive_ready.py
- src/engine/checks/check_automerge_preflight.py
- src/engine/checks/check_baton_freshness.py
- src/engine/checks/check_baton_resolves.py
- src/engine/checks/check_boot_path.py
- src/engine/checks/check_capability_xref.py
- src/engine/checks/check_card_residue.py
- src/engine/checks/check_claim_provenance.py
- src/engine/checks/check_claims.py
- src/engine/checks/check_dateless_walls.py
- src/engine/checks/check_docs.py
- src/engine/checks/check_engagement.py
- src/engine/checks/check_fastlane_symmetry.py
- src/engine/checks/check_folded_gate.py
- src/engine/checks/check_inbox_append.py
- src/engine/checks/check_model_line.py
- src/engine/checks/check_namespace.py
- src/engine/checks/check_no_false_walls.py
- src/engine/checks/check_orientation_budget.py
- src/engine/checks/check_owner_actions.py
- src/engine/checks/check_recipe_applies_when.py
- src/engine/checks/check_recipe_discovery.py
- src/engine/checks/check_recipe_signature_honesty.py
- src/engine/checks/check_remediate.py
- src/engine/checks/check_seam_authority.py
- src/engine/checks/check_seat_digest.py
- src/engine/checks/check_session_log.py
- src/engine/checks/check_setup_script.py
- src/engine/checks/check_skill_grounds.py
- src/engine/checks/check_staged_regen.py
- src/engine/checks/check_stale_walls.py
- src/engine/checks/check_status_current.py
- src/engine/checks/check_surface_census.py
- src/engine/checks/check_template_sync.py
- src/engine/checks/check_ungroomed_ideas.py
- src/engine/checks/check_wall_ledger_agreement.py
- src/engine/hooks/stop_check.py
- tests/test_check_adopters_current.py
- tests/test_check_archive_ready.py
- tests/test_check_automerge_preflight.py
- tests/test_check_baton_freshness.py
- tests/test_check_baton_resolves.py
- tests/test_check_bench_integrity.py
- tests/test_check_boot_path.py
- tests/test_check_capability_xref.py
- tests/test_check_card_residue.py
- tests/test_check_changelog_structure.py
- tests/test_check_claim_provenance.py
- tests/test_check_claims.py
- tests/test_check_dateless_walls.py
- tests/test_check_engagement.py
- tests/test_check_fastlane_symmetry.py
- tests/test_check_folded_gate.py
- tests/test_check_idea_index.py
- tests/test_check_inbox_append.py
- tests/test_check_model_line.py
- tests/test_check_namespace.py
- tests/test_check_no_false_walls_leg.py
- tests/test_check_orientation_budget.py
- tests/test_check_owner_actions.py
- tests/test_check_parity.py
- tests/test_check_program_law.py
- tests/test_check_recipe_applies_when.py
- tests/test_check_recipe_discovery.py
- tests/test_check_recipe_signature_honesty.py
- tests/test_check_remediate.py
- tests/test_check_retro_index.py
- tests/test_check_seam_authority.py
- tests/test_check_setup_script.py
- tests/test_check_skill_grounds.py
- tests/test_check_staged_regen.py
- tests/test_check_stale_walls.py
- tests/test_check_status_current.py
- tests/test_check_surface_census.py
- tests/test_check_taxonomy_sync.py
- tests/test_check_template_sync.py
- tests/test_check_ungroomed_ideas.py
- tests/test_check_wall_ledger_agreement.py
- tests/test_checks.py
- tests/test_hook_stop_check.py
- tools/check_no_false_walls.py

### kit skills shipped

### hook-related files
- .sessions/2026-07-19-r4-hook-census.md
- .substrate/hooks/README.md
- .substrate/hooks/settings.template.json
- src/engine/hooks/__init__.py
- src/engine/hooks/post_edit.py
- src/engine/hooks/session_start.py
- src/engine/hooks/settings.py
- src/engine/hooks/stance_guard.py
- src/engine/hooks/stop_check.py
- tests/test_hook_post_edit.py
- tests/test_hook_session_start.py
- tests/test_hook_settings.py
- tests/test_hook_stop_check.py
- tests/test_hooks.py

## D · installed skills (fleet-manager docs/SKILLS-local.md)
| skill | body | what it does |
|---|---|---|
| `analysis` | kit | Read-only deep-dive: investigate and report findings without changing anything. |
| `asset-pipeline` | local | A delivered generated image → engine-ready asset: key by corner sample, despill at full resolution, downscale to the contract size, three-scale fringe audit, source-record entry. |
| `audio-prompt` | local | Any audio ask — SFX, loops, music stems — by either route, against the committed contract: mono 44.1 kHz 16-bit WAV, sub-0 dBFS with edge fades, manifested, loops mathematically continuous. |
| `capability-probe` | local | Test what a session can do and record it correctly — before declaring anything impossible, and after discovering something works. Produces a well-formed `CAPABILITIES.md` entry with venue token and verbatim evidence. |
| `chase-references` | kit | Resolve every reference in the ask before acting — inventory, resolve or search each one, report unfindables explicitly, state the assembled picture back. |
| `continuation-prompt` | local | Carry a planning or working session into a fresh one — harvest this chat's decisions, verify state at HEAD, commit what should be committed, emit a paste-ready prompt. |
| `cover-art-prompt` | local | Cover art, key art, app icons, banners, store assets — full-bleed, no chroma, silhouette read, short in-image text allowed and tested. Loads on top of `image-prompt`. |
| `decision-capture` | local | Turn decisions that exist only in a conversation into a committed record, so the next prompt points at them instead of carrying them. |
| `deep-research` | kit | Fan out web research, adversarially verify sources, synthesize a cited report. |
| `delegate-read` | local | Hand a read-heavy job to Gemini instead of burning session context, and get back claims citation-verified against the repo before you read them. |
| `image-prompt` | local | The shared method for **any** image-generation prompt — eight sections, anchored to an existing asset, one asset per call, chroma-keyed, function criterion, acceptance question. Routes to the three type skills. |
| `implementation-prompt` | local | Direct a session to build a defined thing — scope and non-scope, the contract, where the patterns live, the verify command, landing discipline, the traps that actually bit. |
| `intake` | kit, **fm-extended 2026-08-09** | Turn a fragmented owner ask into a provenance-separated **intent map** — what he said · what the repo already decided · what you inferred · what is genuinely open — plus goal, non-goals, success test and an `INTENT STATUS` verdict, before planning. The old single "fuller picture" paragraph is gone: fusing those four is the failure it now prevents. |
| `owner-brief` | local | The owner's status brief on demand — what landed, what needs his eyes, what happens next — plain language, zero technical vocabulary, decisions as one-letter choices. |
| `parallax-prompt` | local | Parallax background layers and wall/rail materials — one layer per call, far layer opaque, mid/near on chroma, tiling only where the renderer needs it. Loads on top of `image-prompt`. |
| `prep-owner-steps` | kit, **fm-amended** | Hand the owner finished steps, not directions — deep links, paste-ready blobs, his path walked once, one batched sitting, payoff + verification stated. |
| `prompt-preflight` | local | The checks to run before writing **any** session prompt — verify state at HEAD, split repo-held from chat-held, read the target surface's constraints. |
| `quality-gate` | kit, **fm-amended** | Run the project's full verification before pushing and report what must be fixed. |
| `question` | kit | Answer a direct question concisely from memory and source; make no changes. |
| `rationalize` | kit | The checkpoint at natural pauses — should this action also be executed? does this lesson deserve a permanent home shippable NOW? |
| `release` | kit, **fm-amended** | Cut + publish a substrate-kit release — version bump PR, `workflow_dispatch` publish, three-way asset verification, adopter distribution wave. |
| `repo-health` | kit | Audit doc + session-log hygiene (bootstrap check) and summarize drift. |
| `review` | kit | Review the branch diff against the binding contracts; comment with a verdict and fixes, no edits. |
| `scope-backlog-item` | kit, **fm-amended** | Turn a raw backlog item into a turnkey recipe or an owner ask — chase its origin, classify buildable/owner-gated/dead, write the sized recipe with acceptance + traps. |
| `session-close` | kit, **fm-amended** | Land the session — claim, born-red card first, READY PR, batched work, close-out docs, flip complete last; land on green. |
| `sprite-prompt` | local | A character/object sprite that must slot into an existing set — canonical camera and layout, enumerated body parts, chroma field, runtime dimensions. Loads on top of `image-prompt`. |
| `upgrade-distribution` | kit, **fm-amended** | Roll a kit release out to one adopter repo — download, sha256 three-way, banked rollback, carve-out scan, born-red PR, tree-verified merge. |
| kit-named skill | local amendment at risk | added |
|---|---|---|
| `session-close` | the live-venue rewrite (2026-08-04, owner-ratified 08-05), the Layer 2 handoff line (2026-08-08), the `adversarial-review.md` link depth fix (2026-08-10 — `../../` resolved to `.claude/docs/`, one level short; **until 2026-08-11 no checker covered `.claude/`**, so the revert was undetectable — `scripts/check_docs_links.py` now scans it, advisory and standalone, so a hand run catches a reverted broken link though nothing in CI runs it), **and the no-open-PR correction in two places — step 3's within-session bound and the new step 7b unanswered-fork exit (2026-08-14 — the staged copy still licenses a `do-not-automerge` PR to wait for the owner with no session bound, contradicting the owner's nothing-waits-in-an-open-PR ruling in the decisions ledger, and has no 7b: the terminal card + owner ask must land on `main` via a mergeable records-only PR BEFORE the work PR closes; the dist's embedded template carries the same superseded text, routed upstream as kit worklist row 23 — which takes effect on the next hand-run copy/install, not on upgrade)** | — |
| **`intake`** | **the entire Phase 2 intent map** — the seven-part provenance separation, the retrieval step, the LOW/MEDIUM/HIGH classes and `INTENT STATUS` — **plus the § 4.8 test-result note in the replay section (both halves — fm #851 producer, fm #852 blind scorer) and step 4's decided-items line (decided LOW/MEDIUM report under DECISIONS FLAGGED, never OPEN — fm #852)**. The staged copy at `.substrate/skills/intake/SKILL.md` still contains the superseded `FULLER PICTURE` body, **verified 2026-08-09**, so the copy loop reverts Phase 2 in one command | 2026-08-09 |
| `prep-owner-steps` | the 10-line **Venue note** (`control/` is seat-era historical here; card + PR description are the live venues; owner-ratified 2026-08-05) | 2026-08-04 |
| `release` | the same 10-line Venue note | 2026-08-04 |
| `scope-backlog-item` | the same 10-line Venue note, **plus** step 5's baton retarget to the live venues (2026-08-11 — the staged step writes the baton into retired `control/status.md` and calls that the whole output) | 2026-08-04 |
| `quality-gate` | step 1/2 split corrected (staged copy names `bootstrap.py check --strict` twice and never mentions the false-wall guard) **plus** the 2026-08-11 coverage note — reverting deletes the skill's only pointer to `tools/check_no_false_walls.py` | — |
| `upgrade-distribution` | step 7 verifies `tools/check_no_false_walls.py --strict` explicitly beside the gate (staged copy names the gate twice) | — |
| file | correction | why |
|---|---|---|
| *(none)* | — | — |
| Skill | When to reach for it |
|---|---|
| `prompt-preflight` | Before writing **any** session prompt — verify state at HEAD, split repo-held from chat-held, read the target surface's constraints, define done. Invoked by the two below; run directly when hand-writing a prompt. |
| `continuation-prompt` | A planning or working session is ending and the work continues in a fresh one. Harvests this chat's decisions, verifies state, offers to commit first, emits a paste-ready prompt. |
| `implementation-prompt` | The shape of the work is already agreed and a session needs to build it. Contract, non-scope, the pattern to follow, acceptance, landing discipline, real traps. |
| `decision-capture` | Decisions exist only in a conversation. Lands them in the repo so handoffs become pointers instead of payload. |
| `image-prompt` | The **shared method** for any image-generation prompt (eight sections, hard rules, measured pipeline facts) and the router to the three type skills below. Reverse-derived from the sessions that made spider-swing's art: [`findings/2026-08-04-generated-art-pipeline.md`](findings/2026-08-04-generated-art-pipeline.md). |
| `sprite-prompt` | A character/object sprite that must slot into an existing set — set contract first, anchor + identity exclusion, enumerated layout with a checkable total, neutral stance, chroma by palette. |
| `parallax-prompt` | Parallax background layers and wall/rail materials — one layer per call, far layer opaque, mid/near on chroma, tiling only where the renderer needs it (measured: spider-swing mirrors alternate backdrop tiles), centre stays open. |
